import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { WitnessBoard } from "@/components/witness-board";
import { WitnessForm } from "@/components/witness-form";
import type { FilingRow } from "@/lib/desk-api";

export const Route = createFileRoute("/_desk/x-files")({
  component: XFilesPage,
});

function XFilesPage() {
  const [pending, setPending] = useState<FilingRow[]>([]);

  useEffect(() => {
    try {
      const raw = localStorage.getItem("truthpole-filings-v2");
      if (!raw) return;
      const parsed = JSON.parse(raw) as FilingRow[];
      if (Array.isArray(parsed)) {
        setPending(parsed.filter((f) => f.status === "pending"));
      }
    } catch {
      /* ignore */
    }
  }, []);

  return (
    <section className="mx-auto flex w-full max-w-lg flex-col gap-4 px-5 pt-2 pb-2">
      <p className="font-display text-xs font-medium tracking-kicker text-muted">X-FILES</p>
      <h1 className="font-display text-2xl font-semibold tracking-tight text-fg">Witness board</h1>
      <p className="max-w-prose text-sm leading-normal text-muted">
        Live-style traffic from pilots, towers, and cleared guests. File a report without an account. It will not
        publish until the desk reviews it.
      </p>
      <WitnessForm
        onFiled={(item) => {
          setPending((prev) => [item, ...prev.filter((p) => p.id !== item.id)]);
        }}
      />
      <WitnessBoard pending={pending} />
    </section>
  );
}
