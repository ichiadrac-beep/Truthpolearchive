import { cn } from "@/lib/utils";

type AlienLogoProps = {
  className?: string;
  title?: string;
};

export function AlienLogo({ className, title = "TRUTHPOLE" }: AlienLogoProps) {
  return (
    <svg
      viewBox="0 0 64 80"
      className={cn("text-fg", className)}
      role="img"
      aria-label={title}
    >
      <title>{title}</title>
      <path
        fill="currentColor"
        d="M32 2.5c14.5 0 24.5 10.8 24.5 23.2 0 8.4-4.8 15.4-24.5 33.8C12.3 41.1 7.5 34.1 7.5 25.7 7.5 13.3 17.5 2.5 32 2.5z"
      />
      <path
        fill="var(--color-bg)"
        d="M13.2 28.4c2.4-6.6 11.4-8 16.2-.6-3.6 7.2-12.4 8.4-16.2.6z"
      />
      <path
        fill="var(--color-bg)"
        d="M50.8 28.4c-2.4-6.6-11.4-8-16.2-.6 3.6 7.2 12.4 8.4 16.2.6z"
      />
    </svg>
  );
}
