import { useEffect } from "react";
import { Link } from "@tanstack/react-router";
import { AlienLogo } from "@/components/alien-logo";
import { GlassButton } from "@/components/glass-button";
import { LANDING_TAB_ROWS } from "@/lib/tabs";
import { useDesk } from "@/lib/store";

/** Always-visible sky — inline styles so no CSS black layer can hide it */
function LandingCosmos() {
  const stars: [number, number, number][] = [
    [6, 10, 2], [12, 22, 1.2], [18, 8, 1.6], [24, 30, 1], [30, 14, 1.8],
    [36, 42, 1.1], [42, 6, 1.5], [48, 20, 1], [54, 36, 1.4], [60, 12, 1.2],
    [66, 28, 1.7], [72, 8, 1], [78, 40, 1.5], [84, 16, 1.2], [90, 32, 1.6],
    [94, 50, 1], [8, 48, 1.3], [16, 58, 1], [22, 70, 1.5], [32, 62, 1.1],
    [40, 78, 1.4], [50, 54, 1], [58, 68, 1.6], [68, 80, 1.2], [76, 58, 1],
    [86, 72, 1.5], [92, 64, 1.1], [10, 86, 1.3], [28, 88, 1], [46, 92, 1.4],
    [64, 90, 1.2], [82, 86, 1], [4, 34, 1.5], [20, 40, 1], [34, 24, 1.6],
    [56, 44, 1.2], [70, 48, 1], [88, 24, 1.5], [14, 16, 1.1], [44, 48, 1.3],
  ];

  return (
    <div
      aria-hidden="true"
      style={{
        position: "absolute",
        inset: 0,
        zIndex: 0,
        overflow: "hidden",
        pointerEvents: "none",
        background:
          "radial-gradient(ellipse 80% 50% at 20% 10%, rgba(40,52,78,0.35), transparent 60%), radial-gradient(ellipse 70% 45% at 85% 15%, rgba(58,32,48,0.2), transparent 55%)",
      }}
    >
      {stars.map(([x, y, r], i) => (
        <span
          key={i}
          style={{
            position: "absolute",
            left: `${x}%`,
            top: `${y}%`,
            width: r * 2,
            height: r * 2,
            borderRadius: "50%",
            background: "rgba(243,243,241,0.9)",
            boxShadow: r > 1.4 ? "0 0 4px rgba(200,220,255,0.5)" : undefined,
          }}
        />
      ))}
      {/* constellation top-left */}
      <svg
        viewBox="0 0 100 70"
        width={130}
        height={91}
        style={{ position: "absolute", top: "5%", left: "4%", opacity: 0.55, color: "#f3f3f1" }}
      >
        <path
          d="M12 40 L28 18 L48 28 L62 12 L82 30 M48 28 L58 48 L36 52 L12 40"
          fill="none"
          stroke="currentColor"
          strokeWidth={0.9}
        />
        {[[12, 40], [28, 18], [48, 28], [62, 12], [82, 30], [58, 48], [36, 52]].map(([cx, cy], i) => (
          <circle key={i} cx={cx} cy={cy} r={i === 2 ? 2.2 : 1.5} fill="currentColor" />
        ))}
      </svg>
      {/* shooting streaks */}
      <span
        className="shoot-star"
        style={{
          position: "absolute",
          left: 0,
          top: "18%",
          height: 1,
          width: 180,
          background: "linear-gradient(90deg, transparent, rgba(243,243,241,0.95), transparent)",
          boxShadow: "0 0 8px rgba(180,210,255,0.6)",
        }}
      />
      <span
        className="shoot-star"
        style={{
          position: "absolute",
          left: "5%",
          top: "42%",
          height: 1,
          width: 140,
          background: "linear-gradient(90deg, transparent, rgba(243,243,241,0.9), transparent)",
          animationDelay: "2.5s",
        }}
      />
      {/* glyph marks */}
      <svg viewBox="0 0 16 16" width={20} height={20} className="glyph-float" style={{ position: "absolute", top: "24%", left: "84%", opacity: 0.5, color: "#f3f3f1" }}>
        <path d="M8 0 L10 6 L16 8 L10 10 L8 16 L6 10 L0 8 L6 6 Z" fill="none" stroke="currentColor" strokeWidth={1.2} />
      </svg>
      <svg viewBox="0 0 16 16" width={18} height={18} className="glyph-float" style={{ position: "absolute", top: "72%", left: "8%", opacity: 0.45, color: "#f3f3f1", animationDelay: "2s" }}>
        <path d="M8 1 L15 8 L8 15 L1 8 Z" fill="none" stroke="currentColor" strokeWidth={1.2} />
      </svg>
    </div>
  );
}

export function Landing() {
  const exitHome = useDesk((s) => s.exitHome);
  const clearExitHome = useDesk((s) => s.clearExitHome);

  useEffect(() => {
    if (exitHome) clearExitHome();
  }, [exitHome, clearExitHome]);

  return (
    <main
      className="landing relative z-10 flex min-h-dvh flex-col"
      style={{ background: "transparent" }}
    >
      <LandingCosmos />
      <div className="relative z-10 mx-auto flex w-full max-w-md flex-1 flex-col px-6 pt-[max(2.5rem,env(safe-area-inset-top))]">
        <div className="stagger-in flex flex-1 flex-col items-center justify-center text-center">
          <p className="font-display text-[11px] font-medium tracking-[0.42em] text-fg/55">
            CLASSIFIED DESK
          </p>

          <AlienLogo className="mt-6 h-28 w-28" />

          <h1 className="mt-7 font-display text-[1.65rem] font-semibold tracking-[0.34em] text-fg">
            TRUTHPOLE
          </h1>
          <p className="mt-3 font-display text-[11px] font-medium tracking-[0.46em] text-fg/70">
            · THE ARCHIVE ·
          </p>

          <p className="mt-7 max-w-[34ch] text-[15px] leading-relaxed text-fg/80">
            Sightings on a world map, conspiracy files, ancient contact, live X-Files, and The Pole. A
            black record of what the sky keeps returning.
          </p>

          <div className="relative z-20 mt-9 flex w-full max-w-sm flex-col gap-3">
            <GlassButton asChild variant="primary" className="landing-sheen h-12 rounded-full">
              <Link to="/archive">Enter the archive</Link>
            </GlassButton>
            <GlassButton asChild variant="ghost" className="landing-sheen h-[3.35rem] flex-col rounded-full">
              <Link to="/archive">
                <span className="font-display text-[10px] font-medium tracking-[0.38em] text-fg/55">
                  TONIGHT&apos;S FILE
                </span>
                <span className="font-serif text-[15px] font-normal text-fg">Cussac</span>
              </Link>
            </GlassButton>
          </div>

          <div className="relative z-20 mt-8 flex w-full flex-col items-center gap-2.5">
            {LANDING_TAB_ROWS.map((row, i) => (
              <div key={i} className="flex flex-wrap justify-center gap-2">
                {row.map((tab) => (
                  <GlassButton key={tab.href} asChild variant="chip" className="landing-sheen rounded-full px-4">
                    <Link to={tab.href}>{tab.label}</Link>
                  </GlassButton>
                ))}
              </div>
            ))}
          </div>
        </div>

        <p className="pb-[max(1.25rem,env(safe-area-inset-bottom))] pt-6 text-center font-display text-[10px] tracking-[0.32em] text-fg/40">
          1900 — now
        </p>
      </div>
    </main>
  );
}
