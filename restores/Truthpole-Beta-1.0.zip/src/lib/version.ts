export const APP_VERSION = "1.0.0-beta";
export const APP_VERSION_LABEL = "BETA 1.0";