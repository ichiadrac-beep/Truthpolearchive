import { censorHard } from "@/lib/censor";
import { getSql } from "@/lib/db";
import { guestAlias } from "@/lib/guest-id";
import type { PoleMessage } from "@/lib/desk-api";
import {
  MR_BLACK_ALIAS,
  MR_BLACK_ID,
  MR_BLACK_LINGER_MS,
  USER_TTL_MS,
  dueMrBlackLines,
  isMrBlackName,
} from "@/lib/mr-black";

const TTL_MIN = 6;
const PRESENCE_SEC = 45;
const MAX_BODY = 240;
const MAX_ALIAS = 28;
const MAX_GUEST = 80;
const SEND_GAP_MS = 700;

type Stored = {
  id: string;
  guestId: string;
  alias: string;
  body: string;
  anon: boolean;
  scifCode: string;
  scifTitle: string;
  at: number;
};

type Presence = { guestId: string; at: number };

const g = globalThis as typeof globalThis & {
  __poleMsg__?: Stored[];
  __poleHere__?: Presence[];
  __poleWatch__?: Presence[];
  __poleSend__?: Map<string, number>;
};

function memMsg() {
  g.__poleMsg__ ??= [];
  return g.__poleMsg__;
}
function memHere() {
  g.__poleHere__ ??= [];
  return g.__poleHere__;
}
function memWatch() {
  g.__poleWatch__ ??= [];
  return g.__poleWatch__;
}
function lastSend() {
  g.__poleSend__ ??= new Map();
  return g.__poleSend__;
}

function clipGuest(id: string) {
  const next = id.replace(/[^\w.-]/g, "").slice(0, MAX_GUEST) || "guest";
  if (next === MR_BLACK_ID) return "guest";
  return next;
}

function prune(now: number) {
  g.__poleMsg__ = memMsg()
    .filter((m) => {
      const ttl = m.guestId === MR_BLACK_ID ? MR_BLACK_LINGER_MS : USER_TTL_MS;
      return now - m.at < ttl;
    })
    .slice(-80);
  const live = PRESENCE_SEC * 1000;
  g.__poleHere__ = memHere().filter((p) => now - p.at < live);
  g.__poleWatch__ = memWatch().filter((p) => now - p.at < live && p.guestId !== MR_BLACK_ID);
}

function touchMem(guestId: string, now: number, channel: boolean) {
  const rows = memHere().filter((p) => p.guestId !== guestId);
  rows.push({ guestId, at: now });
  g.__poleHere__ = rows;
  if (channel && guestId !== MR_BLACK_ID) {
    const watch = memWatch().filter((p) => p.guestId !== guestId);
    watch.push({ guestId, at: now });
    g.__poleWatch__ = watch;
  }
}

function occupancy() {
  return memWatch().filter((p) => p.guestId !== MR_BLACK_ID).length;
}

function toMessage(m: Stored, guestId: string, now: number): PoleMessage {
  return {
    id: m.id,
    alias: m.alias,
    body: m.body,
    ageSec: Math.max(0, Math.round((now - m.at) / 1000)),
    mine: m.guestId === guestId && m.guestId !== MR_BLACK_ID,
    anon: m.anon,
    scifCode: m.scifCode,
    scifTitle: m.scifTitle,
  };
}

function snapshotMem(guestId: string, channel: boolean): { online: number; ttlMin: number; messages: PoleMessage[] } {
  const now = Date.now();
  prune(now);
  touchMem(guestId, now, channel);
  const messages = memMsg().map((m) => toMessage(m, guestId, now));
  return { online: Math.max(1, memHere().length), ttlMin: TTL_MIN, messages };
}

type SqlRow = {
  id: string;
  guest_id: string;
  alias: string;
  body: string;
  anon: boolean | number | string;
  scif_code: string;
  scif_title: string;
  at: number;
};

async function snapshotSql(guestId: string, channel: boolean) {
  const sql = await getSql();
  await sql.query(
    `delete from pole_messages
      where (guest_id = $1 and created_at < now() - interval '10 minutes')
         or (guest_id <> $1 and created_at < now() - interval '6 minutes')`,
    [MR_BLACK_ID],
  );
  await sql.query("delete from pole_presence where seen_at < now() - interval '2 minutes'");
  await sql.query(
    `insert into pole_presence (guest_id, seen_at) values ($1, now())
     on conflict (guest_id) do update set seen_at = now()`,
    [guestId],
  );
  const onlineRows = await sql.query<{ n: number }>(
    `select count(*)::int as n from pole_presence where seen_at > now() - interval '${PRESENCE_SEC} seconds'`,
  );
  const rows = await sql.query<SqlRow>(
    `select id, guest_id, alias, body, anon, scif_code, scif_title,
            (extract(epoch from created_at) * 1000)::bigint as at
     from pole_messages
     where created_at > now() - interval '10 minutes'
       and (guest_id = $1 or created_at > now() - interval '6 minutes')
     order by created_at asc
     limit 80`,
    [MR_BLACK_ID],
  );
  const now = Date.now();
  const messages: PoleMessage[] = rows.map((m) =>
    toMessage(
      {
        id: String(m.id),
        guestId: String(m.guest_id),
        alias: String(m.alias),
        body: String(m.body),
        anon: Boolean(m.anon === true || m.anon === "t" || m.anon === 1 || m.anon === "1"),
        scifCode: String(m.scif_code || "SCIF-1"),
        scifTitle: String(m.scif_title || "CONFIDENTIAL"),
        at: Number(m.at),
      },
      guestId,
      now,
    ),
  );
  touchMem(guestId, now, channel);
  return { online: Math.max(1, Number(onlineRows[0]?.n) || 1), ttlMin: TTL_MIN, messages };
}

async function insertBlack(body: string) {
  const now = Date.now();
  const text = censorHard(body).slice(0, MAX_BODY);
  if (!text) return;
  const id = `m-${now.toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  try {
    const sql = await getSql();
    await sql.query(
      `insert into pole_messages (id, guest_id, alias, body, anon, scif_code, scif_title)
       values ($1, $2, $3, $4, $5, $6, $7)`,
      [id, MR_BLACK_ID, MR_BLACK_ALIAS, text, false, "SCIF-1", "CONFIDENTIAL"],
    );
  } catch {
    prune(now);
    memMsg().push({
      id,
      guestId: MR_BLACK_ID,
      alias: MR_BLACK_ALIAS,
      body: text,
      anon: false,
      scifCode: "SCIF-1",
      scifTitle: "CONFIDENTIAL",
      at: now,
    });
  }
}

async function tickBlack(channel: boolean) {
  if (!channel) return;
  const lines = dueMrBlackLines(Date.now(), occupancy());
  for (const body of lines) {
    await insertBlack(body);
  }
}

export async function poleHeartbeat(guestIdRaw: string, channel = false) {
  const guestId = clipGuest(guestIdRaw);
  const now = Date.now();
  prune(now);
  touchMem(guestId, now, channel);
  try {
    await tickBlack(channel);
    return await snapshotSql(guestId, channel);
  } catch {
    await tickBlack(channel);
    return snapshotMem(guestId, channel);
  }
}

export async function poleSend(input: {
  guestId: string;
  body: string;
  anon?: boolean;
  displayName?: string;
  scifCode?: string;
  scifTitle?: string;
}) {
  const guestId = clipGuest(input.guestId);
  const now = Date.now();
  const prev = lastSend().get(guestId) ?? 0;
  if (now - prev < SEND_GAP_MS) {
    return poleHeartbeat(guestId, true);
  }
  lastSend().set(guestId, now);

  const body = censorHard(input.body).slice(0, MAX_BODY);
  if (!body) return poleHeartbeat(guestId, true);

  const anon = Boolean(input.anon);
  const displayName = (input.displayName ?? "").trim().slice(0, MAX_ALIAS);
  const alias = anon
    ? "ANON"
    : isMrBlackName(displayName)
      ? guestAlias(guestId)
      : displayName || guestAlias(guestId);
  const scifCode = (input.scifCode ?? "SCIF-1").slice(0, 12);
  const scifTitle = (input.scifTitle ?? "CONFIDENTIAL").slice(0, 24);
  const id = `m-${now.toString(36)}-${Math.random().toString(36).slice(2, 8)}`;

  try {
    const sql = await getSql();
    await sql.query(
      `insert into pole_messages (id, guest_id, alias, body, anon, scif_code, scif_title)
       values ($1, $2, $3, $4, $5, $6, $7)`,
      [id, guestId, alias, body, anon, scifCode, scifTitle],
    );
    await tickBlack(true);
    return await snapshotSql(guestId, true);
  } catch {
    prune(now);
    memMsg().push({ id, guestId, alias, body, anon, scifCode, scifTitle, at: now });
    touchMem(guestId, now, true);
    await tickBlack(true);
    return snapshotMem(guestId, true);
  }
}