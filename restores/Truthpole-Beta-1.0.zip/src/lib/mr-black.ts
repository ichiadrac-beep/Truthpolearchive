/** Scripted Pole lines. Never a chatbot. Never generated. Never a reply. */

export type BlackCat = "watch" | "files" | "memory" | "warn" | "other";

export type BlackLine = {
  cat: BlackCat;
  body: string;
};

export const MR_BLACK_ID = "__mrblack__";
export const MR_BLACK_ALIAS = "Mr. Black";
export const MR_BLACK_LINGER_MS = 10 * 60 * 1000;
export const USER_TTL_MS = 6 * 60 * 1000;
export const BURST_SPAN_MS = 6 * 60 * 1000;
export const MAX_IN_WINDOW = 3;

const GAP_MIN_MS = Math.round(2.15 * 60 * 60 * 1000);
const GAP_MAX_MS = Math.round(4.7 * 60 * 60 * 1000);
const MIN_POST_GAP_MS = 48_000;
const FIRST_DELAY_MIN = 22_000;
const FIRST_DELAY_MAX = 95_000;

export const BLACK_POOL: BlackLine[] = [
  { cat: "watch", body: "you were seen at 04:12." },
  { cat: "watch", body: "this channel is not as private as you think." },
  { cat: "watch", body: "someone is asking about you." },
  { cat: "watch", body: "we know who was here tonight." },
  { cat: "watch", body: "your last search has been logged." },
  { cat: "watch", body: "we've been listening for longer than you know." },
  { cat: "watch", body: "this conversation continues elsewhere." },
  { cat: "files", body: "that file is not yours to read." },
  { cat: "files", body: "we've adjusted the record." },
  { cat: "files", body: "some pages were never meant to survive." },
  { cat: "files", body: "the file you opened has been flagged." },
  { cat: "files", body: "certain names have been removed from this archive." },
  { cat: "files", body: "what you read tonight will be forgotten by tomorrow." },
  { cat: "files", body: "the original document no longer exists." },
  { cat: "memory", body: "this did not happen." },
  { cat: "memory", body: "you won't remember asking that." },
  { cat: "memory", body: "nothing was said here." },
  { cat: "memory", body: "that question has already been answered. you forgot." },
  { cat: "memory", body: "we've corrected your memory of this." },
  { cat: "warn", body: "curiosity has been noted." },
  { cat: "warn", body: "some doors stay closed for a reason." },
  { cat: "warn", body: "you are closer than you should be." },
  { cat: "warn", body: "step back from this file." },
  { cat: "warn", body: "this is your only notice." },
  { cat: "warn", body: "we don't do this twice." },
  { cat: "other", body: "the sky remembers more than the ground does." },
  { cat: "other", body: "not everyone in this room is who they say." },
  { cat: "other", body: "it's quieter where we are." },
  { cat: "other", body: "you'll understand eventually. or you won't." },
  { cat: "other", body: "some things watch back." },
];

type Pending = { at: number; body: string };
type Posted = { at: number };

type BlackState = {
  deck: BlackLine[];
  nextAt: number;
  pending: Pending[];
  posted: Posted[];
  burstCats: BlackCat[];
};

const g = globalThis as typeof globalThis & { __mrBlack__?: BlackState };

function state(): BlackState {
  if (!g.__mrBlack__) {
    g.__mrBlack__ = {
      deck: shuffle(BLACK_POOL),
      nextAt: Date.now() + randomGap(),
      pending: [],
      posted: [],
      burstCats: [],
    };
  }
  return g.__mrBlack__;
}

function randomGap() {
  return GAP_MIN_MS + Math.random() * (GAP_MAX_MS - GAP_MIN_MS);
}

export function shuffle<T>(items: T[]): T[] {
  const next = items.slice();
  for (let i = next.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    const a = next[i]!;
    next[i] = next[j]!;
    next[j] = a;
  }
  return next;
}

export function takeLine(deck: BlackLine[], lastCat: BlackCat | ""): { line: BlackLine; deck: BlackLine[] } {
  let pile = deck.length ? deck.slice() : shuffle(BLACK_POOL);
  let idx = pile.findIndex((row) => row.cat !== lastCat);
  if (idx < 0) idx = 0;
  const line = pile[idx]!;
  pile.splice(idx, 1);
  if (pile.length === 0) pile = shuffle(BLACK_POOL);
  return { line, deck: pile };
}

export function pickBurst(deck: BlackLine[], n = 0): { lines: BlackLine[]; deck: BlackLine[] } {
  const count = n === 2 || n === 3 ? n : Math.random() < 0.55 ? 2 : 3;
  const lines: BlackLine[] = [];
  let pile = deck.slice();
  let last: BlackCat | "" = "";
  for (let i = 0; i < count; i += 1) {
    const next = takeLine(pile, last);
    pile = next.deck;
    lines.push(next.line);
    last = next.line.cat;
  }
  return { lines, deck: pile };
}

export function burstOffsets(count: number, span = BURST_SPAN_MS) {
  const n = Math.max(2, Math.min(MAX_IN_WINDOW, count));
  const first = FIRST_DELAY_MIN + Math.random() * (FIRST_DELAY_MAX - FIRST_DELAY_MIN);
  const times = [first];
  for (let i = 1; i < n; i += 1) {
    times.push(first + Math.random() * Math.max(1000, span - first));
  }
  times.sort((a, b) => a - b);
  for (let i = 1; i < times.length; i += 1) {
    if (times[i]! < times[i - 1]! + MIN_POST_GAP_MS) {
      times[i] = times[i - 1]! + MIN_POST_GAP_MS;
    }
  }
  const last = times[times.length - 1] ?? 0;
  if (last > span) {
    const step = span / (n + 0.4);
    for (let i = 0; i < n; i += 1) times[i] = Math.min(span - 400, (i + 1) * step);
  }
  return times.slice(0, n);
}

function rollingCount(now: number) {
  const s = state();
  s.posted = s.posted.filter((row) => now - row.at < BURST_SPAN_MS);
  return s.posted.length;
}

function openWindow(now: number) {
  const s = state();
  const picked = pickBurst(s.deck);
  s.deck = picked.deck;
  s.burstCats = picked.lines.map((row) => row.cat);
  const offsets = burstOffsets(picked.lines.length);
  s.pending = picked.lines.map((row, i) => ({
    at: now + (offsets[i] ?? (i + 1) * MIN_POST_GAP_MS),
    body: row.body,
  }));
  s.nextAt = now + BURST_SPAN_MS + randomGap();
}

function closeWindow() {
  const s = state();
  s.pending = [];
  s.burstCats = [];
}

/** Due standalone lines. Empty room → drop the rest. Shared for every viewer. */
export function dueMrBlackLines(now: number, occupancy: number): string[] {
  const s = state();
  if (occupancy < 1) {
    if (s.pending.length) closeWindow();
    return [];
  }
  if (!s.pending.length && now >= s.nextAt) openWindow(now);
  if (!s.pending.length) return [];

  const out: string[] = [];
  const keep: Pending[] = [];
  for (const row of s.pending) {
    if (row.at > now) {
      keep.push(row);
      continue;
    }
    if (rollingCount(now) + out.length >= MAX_IN_WINDOW) {
      keep.push(row);
      continue;
    }
    out.push(row.body);
    s.posted.push({ at: now });
  }
  s.pending = keep;
  return out;
}

export function isMrBlackName(name: string) {
  return /^mr\.?\s*black$/i.test(name.trim());
}

export function resetMrBlack(now = Date.now()) {
  g.__mrBlack__ = {
    deck: shuffle(BLACK_POOL),
    nextAt: now + randomGap(),
    pending: [],
    posted: [],
    burstCats: [],
  };
}

/** QA only — next window fires on the following channel tick. */
export function armMrBlackNow(now = Date.now(), spanMs = 4_800) {
  const s = state();
  const picked = pickBurst(s.deck);
  s.deck = picked.deck;
  s.burstCats = picked.lines.map((row) => row.cat);
  const n = picked.lines.length;
  const step = Math.max(700, Math.floor(spanMs / n));
  s.pending = picked.lines.map((row, i) => ({ at: now + i * step, body: row.body }));
  s.nextAt = now + BURST_SPAN_MS + randomGap();
  s.posted = [];
}
