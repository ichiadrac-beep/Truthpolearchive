import { useEffect, useState } from "react";
import { subscribeClearance } from "@/lib/clearance";
import { pickTonightFile, type TonightPick } from "@/lib/tonight";

function sameTonight(a: TonightPick, b: TonightPick) {
  return (
    a.title === b.title &&
    a.caseId === b.caseId &&
    a.special === b.special &&
    a.anniversary === b.anniversary
  );
}

export function useClearanceTonight(): TonightPick {
  const [tonight, setTonight] = useState<TonightPick>(() => pickTonightFile());
  useEffect(() => {
    const sync = () => {
      const next = pickTonightFile();
      setTonight((prev) => (sameTonight(prev, next) ? prev : next));
    };
    sync();
    const tick = window.setInterval(sync, 60_000);
    const unsub = subscribeClearance(sync);
    return () => {
      window.clearInterval(tick);
      unsub();
    };
  }, []);
  return tonight;
}