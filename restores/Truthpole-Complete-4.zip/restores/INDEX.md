# TRUTHPOLE restore archive index

Ordered backups. **Never overwrite** an existing restore file; always add the next number.

| Order | Label | Artifact |
|------:|-------|----------|
| 0 | **Complete build** | Branch [`complete-build`](https://github.com/ichiadrac-beep/Truthpolearchive/tree/complete-build) · [`COMPLETE-BUILD.md`](./COMPLETE-BUILD.md) · zip [`TRUTHPOLE-restore-20260827-live.zip`](./TRUTHPOLE-restore-20260827-live.zip) |
| 1 | **restore file(1)** | [`restore-file-1.zip`](./restore-file-1.zip) · [`RESTORE-FILE-1.md`](./RESTORE-FILE-1.md) — Archive ↔ Conspiracy ↔ Ancient cross-links |
| 2 | **restore file(2)** | [`restore-file-2.zip`](./restore-file-2.zip) · [`RESTORE-FILE-2.md`](./RESTORE-FILE-2.md) — linked counts, status tags, ticking count, desk decrypt |
| 3 | **Truthpole-Complete 2** | [`Truthpole-Complete-2.zip`](./Truthpole-Complete-2.zip) · [`TRUTHPOLE-COMPLETE-2.md`](./TRUTHPOLE-COMPLETE-2.md) — full desk, Tonight’s file first-paint |
| 4 | **Truthpole-Complete 3** | [`Truthpole-Complete-3.zip`](./Truthpole-Complete-3.zip) · [`TRUTHPOLE-COMPLETE-3.md`](./TRUTHPOLE-COMPLETE-3.md) — Complete 2 + archive scratch + Men in Black + title type-out |
| 5 | **Truthpole-Complete 4** | [`Truthpole-Complete-4.zip`](./Truthpole-Complete-4.zip) · [`TRUTHPOLE-COMPLETE-4.md`](./TRUTHPOLE-COMPLETE-4.md) — Complete 3 + lottery-ticket scratch on Archive & Conspiracy + SIGNAL HUD + rare SIGNAL LOST burst |

## Download

- Complete build zip: https://github.com/ichiadrac-beep/Truthpolearchive/raw/main/restores/TRUTHPOLE-restore-20260827-live.zip
- Complete build branch: https://github.com/ichiadrac-beep/Truthpolearchive/archive/refs/heads/complete-build.zip
- restore file(1): https://github.com/ichiadrac-beep/Truthpolearchive/raw/main/restores/restore-file-1.zip
- restore file(2): https://github.com/ichiadrac-beep/Truthpolearchive/raw/main/restores/restore-file-2.zip
- Truthpole-Complete 2: https://github.com/ichiadrac-beep/Truthpolearchive/raw/main/restores/Truthpole-Complete-2.zip
- Truthpole-Complete 3: https://github.com/ichiadrac-beep/Truthpolearchive/raw/main/restores/Truthpole-Complete-3.zip
- Truthpole-Complete 4: https://github.com/ichiadrac-beep/Truthpolearchive/raw/main/restores/Truthpole-Complete-4.zip
