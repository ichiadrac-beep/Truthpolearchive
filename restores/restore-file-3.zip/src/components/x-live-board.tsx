import { useEffect, useState } from "react";
import { ExternalLink, Radio, RefreshCw } from "lucide-react";
import { GlassButton } from "@/components/glass-button";
import {
  credibilityOf,
  formatCount,
  type XFeedPost,
  X_FEED_ACCOUNTS,
  X_FEED_KEYWORDS,
} from "@/lib/x-feed";

type XLiveBoardProps = {
  posts: XFeedPost[];
  loading: boolean;
  source: "api" | "seed";
  lastRefresh: Date | null;
  onRefresh: () => void;
};

export function XLiveBoard({ posts, loading, source, lastRefresh, onRefresh }: XLiveBoardProps) {
  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="min-w-0">
          <p className="font-display text-[11px] tracking-[0.28em] text-fg/45">
            {source === "api" ? "LIVE · X API" : "LIVE SNAPSHOT"}
          </p>
          <SignalBar scanning={loading} />
          <p className="mt-1 text-xs text-fg/50">
            {lastRefresh
              ? `Updated ${lastRefresh.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`
              : "Waiting for first pull"}
            {" · last 48h · newest first · auto every 3 min"}
          </p>
        </div>
        <GlassButton
          type="button"
          variant="chip"
          className="h-9 gap-2 px-3"
          disabled={loading}
          onClick={onRefresh}
          aria-label="Fetch latest posts"
        >
          <RefreshCw className={`size-3.5 ${loading ? "animate-spin" : ""}`} strokeWidth={1.8} />
          {loading ? "Fetching…" : "Fetch latest"}
        </GlassButton>
      </div>

      <div className="glass-plain rounded-2xl px-3 py-2.5">
        <p className="font-display text-[10px] tracking-[0.22em] text-fg/40">WATCHING</p>
        <p className="mt-1.5 text-[11px] leading-relaxed text-fg/55">
          {X_FEED_ACCOUNTS.map((h) => `@${h}`).join(" · ")}
        </p>
        <p className="mt-2 font-display text-[10px] tracking-[0.22em] text-fg/40">KEYWORDS</p>
        <p className="mt-1.5 text-[11px] leading-relaxed text-fg/55">
          {X_FEED_KEYWORDS.join(" · ")}
        </p>
        <p className="mt-2.5 text-[11px] leading-snug text-fg/45">
          Credibility scores are a desk heuristic from available engagement, links, and media — not
          official truth ratings.
        </p>
      </div>

      <ul className="flex flex-col gap-3">
        {posts.map((post) => {
          const cred = credibilityOf(post);
          const handle = (post.handle || "").replace(/^@/, "").trim();
          if (!handle || handle.toLowerCase() === "desk") return null;
          const name =
            post.name && post.name.replace(/^@/, "").toLowerCase() !== "desk"
              ? post.name.replace(/^@/, "")
              : handle;
          const missingCounts = post.likes == null && post.reposts == null && post.replies == null;
          return (
            <li key={post.id}>
              <article className="glass-plain-strong rounded-2xl px-4 py-3.5">
                <header className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <a
                      href={`https://x.com/${handle}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block truncate font-display text-[13px] font-semibold tracking-[0.14em] text-fg"
                    >
                      @{handle}
                    </a>
                    <p className="mt-0.5 truncate text-sm text-fg/70">{name}</p>
                  </div>
                  <p className="shrink-0 font-display text-[10px] tracking-[0.18em] text-fg/40">
                    {post.when}
                  </p>
                </header>
                <p className="mt-3 text-sm leading-relaxed text-fg/90">{post.text}</p>

                <div className="mt-3 rounded-2xl bg-fg/6 px-3 py-2.5">
                  <Meter
                    label="OVERALL"
                    value={cred.overall}
                    hint={cred.label}
                    emphasize
                  />
                  <div className="mt-2 grid grid-cols-3 gap-2">
                    <Meter
                      label="VIRALITY"
                      value={cred.virality}
                      hint={
                        missingCounts
                          ? "Counts pending"
                          : `${formatCount(post.likes)} likes · ${formatCount(post.reposts)} rt`
                      }
                    />
                    <Meter
                      label="COMMENTS"
                      value={cred.comments}
                      hint={
                        missingCounts
                          ? "Signal pending"
                          : `${formatCount(post.replies)} replies`
                      }
                    />
                    <Meter
                      label="EVIDENCE"
                      value={cred.evidence}
                      hint={post.hasMedia ? "Media + links" : "Source + links"}
                    />
                  </div>
                  <p className="mt-2 text-[10px] leading-snug text-fg/40">
                    Desk heuristic from engagement, links, and media — not an official truth rating.
                  </p>
                </div>

                <footer className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2">
                  {post.views != null ? (
                    <span className="font-display text-[10px] tracking-[0.16em] text-fg/40">
                      {formatCount(post.views)} views
                    </span>
                  ) : null}
                  {post.hasMedia ? (
                    <span className="inline-flex items-center gap-1 font-display text-[10px] tracking-[0.16em] text-fg/50">
                      <Radio className="size-3" strokeWidth={1.6} />
                      media
                    </span>
                  ) : null}
                  <a
                    href={post.url.startsWith("http") ? post.url : `https://x.com/${handle}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="ml-auto inline-flex items-center gap-1 font-display text-[10px] tracking-[0.18em] text-fg/70 underline decoration-fg/25 underline-offset-2"
                  >
                    Open on X
                    <ExternalLink className="size-3" strokeWidth={1.6} />
                  </a>
                </footer>
              </article>
            </li>
          );
        })}
      </ul>

      {posts.length === 0 ? (
        <p className="py-8 text-center text-sm text-fg/50">No posts matched the keyword filter.</p>
      ) : null}
    </div>
  );
}

function SignalBar({ scanning }: { scanning: boolean }) {
  const [level, setLevel] = useState(4);
  const [flicker, setFlicker] = useState(scanning);

  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) {
      setFlicker(false);
      setLevel(4);
      return;
    }
    if (scanning) {
      setFlicker(true);
      const id = window.setInterval(() => {
        setLevel(1 + Math.floor(Math.random() * 5));
      }, 78);
      return () => window.clearInterval(id);
    }
    const lock = window.setTimeout(() => {
      setFlicker(false);
      setLevel(4);
    }, 420);
    return () => window.clearTimeout(lock);
  }, [scanning]);

  const cells = [1, 2, 3, 4, 5].map((n) => (n <= level ? "▮" : "▯")).join("");

  return (
    <p
      className="mt-1.5 font-mono text-[12px] tracking-[0.18em] text-fg/70"
      role="status"
      aria-live="polite"
      aria-label={`Signal ${level} of 5${flicker ? ", locking" : ""}`}
    >
      <span className="text-fg/40">SIGNAL:</span>{" "}
      <span className={flicker ? "text-fg" : "text-fg/80"}>{cells}</span>
      <span className="ml-2 font-display text-[10px] tracking-[0.22em] text-fg/40">
        {flicker ? "LOCKING" : "LOCKED"}
      </span>
    </p>
  );
}

function Meter({
  label,
  value,
  hint,
  emphasize,
}: {
  label: string;
  value: number;
  hint: string;
  emphasize?: boolean;
}) {
  return (
    <div className={emphasize ? "" : "min-w-0"}>
      <dt className="font-display text-[10px] tracking-[0.16em] text-fg/45">{label}</dt>
      <div className={emphasize ? "flex items-baseline gap-2" : ""}>
        <dd className={`mt-0.5 leading-none text-fg ${emphasize ? "font-serif text-2xl" : "font-serif text-base"}`}>
          {value}
        </dd>
        {emphasize ? (
          <span className="font-display text-[10px] tracking-[0.18em] text-fg/50">{hint}</span>
        ) : null}
      </div>
      <div className="mt-1.5 h-0.5 rounded-full bg-fg/15">
        <div
          className="h-0.5 rounded-full bg-fg/75"
          style={{ width: `${Math.max(4, Math.min(100, value))}%` }}
        />
      </div>
      {!emphasize ? <p className="mt-1 text-[10px] leading-tight text-fg/40">{hint}</p> : null}
    </div>
  );
}
