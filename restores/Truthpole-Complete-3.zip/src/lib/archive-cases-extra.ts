export const ARCHIVE_CASES_EXTRA = [
  {
    id: "aurora-airship",
    title: "Aurora airship",
    place: "Aurora, Texas",
    country: "USA",
    year: 1897,
    lat: 33.06,
    lng: -97.506,
    summary: "In April 1897, during the U.S. mystery-airship wave, the Dallas Morning News printed a local claim that a cigar-shaped craft had struck a windmill on Judge J. S. Proctor’s farm, killing a small pilot buried in the town cemetery. No wreckage was produced in later searches. Skeptics treat the item as a hoax or a newspaper yarn; ufologists keep it as the first American crash-retrieval story in print.",
    sources: [
          "Dallas Morning News, 19 April 1897",
          "Texas historical society notes on the Aurora airship tale"
    ],
  },
  {
    id: "tunguska",
    title: "Tunguska",
    place: "Podkamennaya Tunguska",
    country: "Russia",
    year: 1908,
    lat: 60.886,
    lng: 101.894,
    summary: "On 30 June 1908 an explosion flattened some 2,000 km² of taiga near the Stony Tunguska. No crater of a typical iron meteorite was found. The leading account is an airburst of a stony body. Contact literature has long asked whether the missing crater hides a craft. Seismic, tree-fall, and later expeditions still fit an atmospheric explosion better than a landing.",
    sources: [
          "Kulik expeditions, 1920s",
          "Russian Academy of Sciences Tunguska reviews"
    ],
  },
  {
    id: "foo-fighters",
    title: "Foo Fighters",
    place: "Rhine Valley",
    country: "Germany",
    year: 1944,
    lat: 50.082,
    lng: 8.24,
    summary: "From late 1944, Allied night-fighter crews over the Rhine and occupied Europe reported balls of light that paced bombers, then peeled away. Airmen called them foo fighters. Intelligence sections logged the reports as unidentified; German and Japanese crews filed similar notes. No recovered device matched the descriptions. The file is the first large military-aircrew UAP series of the war.",
    sources: [
          "USAAF / RAF intelligence summaries, 1944–45",
          "Keith Chester, Strange Company"
    ],
  },
  {
    id: "cape-girardeau",
    title: "Cape Girardeau",
    place: "Cape Girardeau, Missouri",
    country: "USA",
    year: 1941,
    lat: 37.306,
    lng: -89.518,
    summary: "A second-hand 1941 story, later told by a Baptist minister’s family, describes a crashed disc and small bodies recovered near Cape Girardeau and taken by the military. There is no contemporary newspaper or Army paper that confirms a crash. The account entered ufology decades later through Leonard Stringfield’s crash-retrieval catalogs. It remains an unverified early-war retrieval claim.",
    sources: [
          "Leonard Stringfield crash-retrieval status reports",
          "Local Cape Girardeau oral history as later collected"
    ],
  },
  {
    id: "trinity-san-antonio",
    title: "Trinity / San Antonio",
    place: "San Antonio, New Mexico",
    country: "USA",
    year: 1945,
    lat: 33.918,
    lng: -106.87,
    summary: "Jacques Vallée and Paola Harris published a 1945 crash story from San Antonio, New Mexico, two weeks after the Trinity nuclear test: a small craft, child-sized occupants, and a later Army recovery. The witnesses were children at the time. No 1945 military document has been matched to the site. It is now one of the most argued ‘pre-Roswell’ retrieval files.",
    sources: [
          "Vallée & Harris, Trinity (2021)",
          "Manhattan Project / Trinity site chronology"
    ],
  },
  {
    id: "hanford-1945",
    title: "Hanford overflight",
    place: "Hanford Engineer Works",
    country: "USA",
    year: 1945,
    lat: 46.55,
    lng: -119.49,
    summary: "Manhattan Project security and later declassified notes describe unidentified aircraft over the Hanford plutonium works in 1944–45, including a 23 July 1945 scramble. Fighters found nothing they could identify. Nuclear sites attract both classified flights and later UFO lore. The Hanford paper is real; the identification is not.",
    sources: [
          "Manhattan Project security logs as later released",
          "Hanford site historical records"
    ],
  },
  {
    id: "kenneth-arnold",
    title: "Kenneth Arnold",
    place: "Mount Rainier, Washington",
    country: "USA",
    year: 1947,
    lat: 46.853,
    lng: -121.76,
    summary: "On 24 June 1947 private pilot Kenneth Arnold reported nine objects crossing the Cascades near Mount Rainier at extraordinary speed. He told reporters they moved like saucers skipping on water; the press coined ‘flying saucer.’ Arnold never recanted. No squadron later claimed a formation that matched his times. The sighting opened the modern U.S. wave.",
    sources: [
          "Arnold interview, East Oregonian, June 1947",
          "Project Sign / Blue Book Arnold card"
    ],
  },
  {
    id: "maury-island",
    title: "Maury Island",
    place: "Maury Island, Puget Sound",
    country: "USA",
    year: 1947,
    lat: 47.378,
    lng: -122.428,
    summary: "Harbor patrolman Harold Dahl said slag fell from a doughnut-shaped object over Maury Island in June 1947. Two Army officers later died when their B-25, carrying samples, crashed. The FBI treated the story as a hoax. Ufologists still argue over the slag and the dead investigators. It is the first messy crash-and-debris file of the saucer year.",
    sources: [
          "FBI Maury Island file",
          "Kenneth Arnold and Ray Palmer contemporary accounts"
    ],
  },
  {
    id: "mantell",
    title: "Mantell incident",
    place: "Franklin, Kentucky",
    country: "USA",
    year: 1948,
    lat: 36.722,
    lng: -86.577,
    summary: "On 7 January 1948, Kentucky Air National Guard captain Thomas Mantell died after climbing his F-51 toward a high white object. The Air Force later said a Skyhook balloon. Mantell’s last radio described a metallic object. The crash is not disputed. The identification still splits balloon, Venus, and unknown.",
    sources: [
          "Project Sign / Blue Book Mantell file",
          "Kentucky ANG accident report, Jan 1948"
    ],
  },
  {
    id: "gorman-dogfight",
    title: "Gorman dogfight",
    place: "Fargo, North Dakota",
    country: "USA",
    year: 1948,
    lat: 46.877,
    lng: -96.79,
    summary: "On 1 October 1948, Air National Guard lieutenant George Gorman chased a small light over Fargo for more than twenty minutes. Tower operators also saw it. Project Sign called it a lighted weather balloon; Gorman did not. The case is a clean early fighter-vs-light file with multiple ground witnesses.",
    sources: [
          "Project Sign, Gorman case",
          "Hector Airport tower notes, 1 Oct 1948"
    ],
  },
  {
    id: "chiles-whitted",
    title: "Chiles–Whitted",
    place: "Montgomery, Alabama",
    country: "USA",
    year: 1948,
    lat: 32.379,
    lng: -86.308,
    summary: "In the early hours of 24 July 1948, Eastern Air Lines pilots Clarence Chiles and John Whitted reported a double-decked, windowed craft with a torch-like exhaust that shot past their DC-3. A passenger glimpsed a light. Project Sign took it seriously; later Blue Book preferred a meteor. The cockpit report does not read like a meteor.",
    sources: [
          "Project Sign Chiles–Whitted file",
          "Eastern Air Lines crew statements, July 1948"
    ],
  },
  {
    id: "aztec-nm",
    title: "Aztec crash claim",
    place: "Aztec, New Mexico",
    country: "USA",
    year: 1948,
    lat: 36.822,
    lng: -107.993,
    summary: "Silas Newton and Leo GeBauer sold a 1948 story of a recovered disc on a mesa near Aztec, later popularized in Frank Scully’s Behind the Flying Saucers. A 1950s journalist exposed a con. Some researchers still argue a real crash sat under the fraud. No authenticated wreckage has been produced.",
    sources: [
          "Frank Scully, Behind the Flying Saucers (1950)",
          "J. P. Cahn exposé, True magazine, 1952"
    ],
  },
  {
    id: "green-fireballs",
    title: "Green fireballs",
    place: "Los Alamos",
    country: "USA",
    year: 1949,
    lat: 35.881,
    lng: -106.304,
    summary: "From 1948 into 1951, green fireballs were reported over New Mexico nuclear sites, including Los Alamos and Sandia. Dr. Lincoln LaPaz investigated for the Air Force; Project Twinkle followed. Conventional meteors did not satisfy the color, trajectories, or clustering. No device was recovered. The official study closed unsolved.",
    sources: [
          "Project Twinkle reports",
          "LaPaz correspondence on New Mexico fireballs"
    ],
  },
  {
    id: "mcmminville",
    title: "McMinnville / Trent",
    place: "McMinnville, Oregon",
    country: "USA",
    year: 1950,
    lat: 45.21,
    lng: -123.197,
    summary: "On 11 May 1950, Paul and Evelyn Trent photographed a disc over their farm near McMinnville. The two stills survived stereo and shadow analysis for decades. The Condon Report could not dismiss them as a model. Skeptics still argue a hanging truck mirror. The negatives remain among the most studied civilian UFO photographs.",
    sources: [
          "Condon Report, McMinnville case",
          "Original Trent negatives / press prints, 1950"
    ],
  },
  {
    id: "mariana-film",
    title: "Mariana film",
    place: "Great Falls, Montana",
    country: "USA",
    year: 1950,
    lat: 47.494,
    lng: -111.283,
    summary: "Nick Mariana filmed two bright objects passing behind a water tower in Great Falls on 15 August 1950. The Air Force said jets; later frame studies argued against that. Blue Book carried the film. It is one of the earliest daylight motion records still in official files.",
    sources: [
          "Project Blue Book, Mariana / Great Falls film",
          "Montana contemporaneous press, Aug 1950"
    ],
  },
  {
    id: "farmington-armada",
    title: "Farmington armada",
    place: "Farmington, New Mexico",
    country: "USA",
    year: 1950,
    lat: 36.728,
    lng: -108.219,
    summary: "On 17 March 1950, hundreds of people in Farmington reported a sky full of discs, some said to maneuver at high speed. Newspapers treated it as a mass sighting, not a joke. The Air Force later pointed at aircraft or debris. No flight plan explained an armada. It is a little-cited daylight mass case next door to the nuclear west.",
    sources: [
          "Farmington Daily Times, 18 March 1950",
          "Blue Book Farmington cards"
    ],
  },
  {
    id: "oak-ridge-1950",
    title: "Oak Ridge overflight",
    place: "Oak Ridge, Tennessee",
    country: "USA",
    year: 1950,
    lat: 35.931,
    lng: -84.31,
    summary: "Security and radar at the Oak Ridge nuclear reservation logged unidentified lights and returns in 1950, with fighters scrambled. The Atomic Energy Commission took the reports as a real airspace problem. Blue Book and FBI notes survive. Identification never closed cleanly. Nuclear-site unknowns are a pattern, not a one-off.",
    sources: [
          "FBI / AEC Oak Ridge UFO traffic",
          "Project Blue Book Oak Ridge cards"
    ],
  },
  {
    id: "lubbock-lights",
    title: "Lubbock Lights",
    place: "Lubbock, Texas",
    country: "USA",
    year: 1951,
    lat: 33.577,
    lng: -101.855,
    summary: "In August–September 1951, professors at Texas Tech and many townsfolk saw V-formations of lights over Lubbock. Carl Hart Jr. photographed them. Blue Book first said plover, then reversed. The photographs remain disputed. The case is a classic multiple-witness night formation.",
    sources: [
          "Project Blue Book, Lubbock Lights",
          "Texas Tech faculty statements, 1951"
    ],
  },
  {
    id: "fort-monmouth",
    title: "Fort Monmouth",
    place: "Fort Monmouth, New Jersey",
    country: "USA",
    year: 1951,
    lat: 40.314,
    lng: -74.044,
    summary: "On 10–11 September 1951, Army radar and an Air Force T-33 crew reported an unknown near Fort Monmouth and Sandy Hook. The incident helped trigger a Pentagon review of the UFO program. Blue Book later preferred a balloon. The radar-visual pairing is why the file still matters.",
    sources: [
          "Project Blue Book, Fort Monmouth 1951",
          "Air Force intelligence briefing notes, Sept 1951"
    ],
  },
  {
    id: "nash-fortenberry",
    title: "Nash–Fortenberry",
    place: "Norfolk, Virginia",
    country: "USA",
    year: 1952,
    lat: 36.85,
    lng: -76.29,
    summary: "On 14 July 1952, Pan American pilots William Nash and William Fortenberry reported eight discs in line, flipping, then accelerating away beneath their DC-4 over Chesapeake Bay. Several ground witnesses reported lights. Blue Book listed it unidentified. It is a strong aircrew daylight-night case from the 1952 wave.",
    sources: [
          "Project Blue Book, Nash–Fortenberry",
          "Pan American crew report, 14 July 1952"
    ],
  },
  {
    id: "tremonton",
    title: "Tremonton film",
    place: "Tremonton, Utah",
    country: "USA",
    year: 1952,
    lat: 41.712,
    lng: -112.166,
    summary: "Navy warrant officer Delbert Newhouse filmed a group of bright objects near Tremonton on 2 July 1952. Photo-lab analysis at Wright-Patterson did not identify birds or aircraft to everyone’s satisfaction. The Robertson Panel later leaned toward gulls. The footage is still one of Blue Book’s key motion studies.",
    sources: [
          "USAF Photo Reconnaissance Laboratory notes",
          "Robertson Panel discussion of the Tremonton film"
    ],
  },
  {
    id: "flatwoods",
    title: "Flatwoods Monster",
    place: "Flatwoods, West Virginia",
    country: "USA",
    year: 1952,
    lat: 38.723,
    lng: -80.65,
    summary: "On 12 September 1952 a group from Flatwoods walked a hill after a bright object appeared to land. They described a tall, hooded figure with a pungent mist; several fell ill. The Air Force suggested a meteor and an owl. Local medical and press notes exist. It is a high-strangeness close encounter, not a distant light.",
    sources: [
          "Braxton County press, Sept 1952",
          "Project Blue Book Flatwoods card"
    ],
  },
  {
    id: "salem-coast-guard",
    title: "Salem Coast Guard",
    place: "Salem, Massachusetts",
    country: "USA",
    year: 1952,
    lat: 42.52,
    lng: -70.887,
    summary: "On 16 July 1952 a Coast Guard photographer at the Salem Air Station shot four luminous objects in daylight. The print was widely published. Blue Book preferred reflections or internal camera artifacts. The station log is real. The photograph is still argued as a New England 1952-wave still.",
    sources: [
          "U.S. Coast Guard Salem photograph, 16 July 1952",
          "Project Blue Book Salem card"
    ],
  },
  {
    id: "topcliffe",
    title: "RAF Topcliffe",
    place: "RAF Topcliffe, North Yorkshire",
    country: "UK",
    year: 1952,
    lat: 54.206,
    lng: -1.39,
    summary: "On 19 September 1952, RAF personnel at Topcliffe, including a visiting U.S. Air Force officer, reported a silver disc that descended, hovered, then sped away as a Meteor took off. The report went to Fighter Command. It is an early official British daylight disc from the NATO airfield chain.",
    sources: [
          "UK National Archives, Air Ministry UFO papers",
          "RAF Topcliffe station reports, Sept 1952"
    ],
  },
  {
    id: "little-rissington",
    title: "Little Rissington",
    place: "RAF Little Rissington",
    country: "UK",
    year: 1952,
    lat: 51.867,
    lng: -1.877,
    summary: "In October 1952 a Meteor crew from Little Rissington reported a radar-visual unknown over Gloucestershire that outpaced the jet. The incident sat in Air Ministry files later released. It is a lesser-known British radar-visual from the same autumn as Topcliffe.",
    sources: [
          "UK National Archives, Air Ministry UFO files",
          "RAF Flying Training Command notes, 1952"
    ],
  },
  {
    id: "kingman-az",
    title: "Kingman crash claim",
    place: "Kingman, Arizona",
    country: "USA",
    year: 1953,
    lat: 35.189,
    lng: -114.053,
    summary: "Arthur Stansel (as ‘Fritz Werner’) later described a 1953 assignment to a crash site near Kingman: a disc and small bodies under military guard. The affidavit is decades after the fact. No 1953 Army paper has been matched. Kingman remains a named retrieval claim without a contemporary primary.",
    sources: [
          "Raymond Fowler / Stansel affidavit as published",
          "Mohave County 1953 press (no crash confirmation)"
    ],
  },
  {
    id: "antananarivo",
    title: "Antananarivo",
    place: "Antananarivo",
    country: "Madagascar",
    year: 1954,
    lat: -18.879,
    lng: 47.508,
    summary: "On 16 August 1954 a large, green-glowing object was reported over Antananarivo, with panic in the streets and a possible electromagnetic effect on a rolling stock. French colonial notes and later GEIPAN-era summaries keep the case. It is one of the few well-cited African/Indian Ocean daylight-night events of the 1954 wave.",
    sources: [
          "French colonial / police notes, Aug 1954",
          "GEIPAN historical case summaries"
    ],
  },
  {
    id: "quarouble",
    title: "Quarouble",
    place: "Quarouble, Nord",
    country: "France",
    year: 1954,
    lat: 50.389,
    lng: 3.623,
    summary: "On 10 September 1954, Marius Dewilde reported two small beings and a dark craft on a railway embankment at Quarouble. Gendarmes found crushed stone and, Dewilde said, a lasting patch of dead grass. The 1954 French wave produced many such close encounters; Quarouble is among the best-documented by police.",
    sources: [
          "Gendarmerie nationale, Quarouble 1954",
          "GEIPAN / GEPAN historical file"
    ],
  },
  {
    id: "kelly-hopkinsville",
    title: "Kelly–Hopkinsville",
    place: "Kelly, Kentucky",
    country: "USA",
    year: 1955,
    lat: 36.912,
    lng: -87.483,
    summary: "On the night of 21–22 August 1955, a farm family near Kelly opened fire on small luminous figures they said surrounded the house. Police and a Fort Campbell MP found no beings, only frightened witnesses and bullet holes. The ‘goblin’ case is a close-encounter classic with a contemporary police report.",
    sources: [
          "Hopkinsville police reports, Aug 1955",
          "Project Blue Book Kelly-Hopkinsville card"
    ],
  },
  {
    id: "cook-strait",
    title: "Cook Strait",
    place: "Cook Strait",
    country: "New Zealand",
    year: 1956,
    lat: -41.3,
    lng: 174.78,
    summary: "In 1956, aircrew and ship observers reported unidentified lights over Cook Strait, logged in RNZAF and civil files later released. New Zealand’s official UFO paper is thinner than the UK’s, which is why this strait series is often missed. It sits as an early Australasian aircrew file.",
    sources: [
          "RNZAF unidentified aircraft notes, 1956",
          "New Zealand civil aviation summaries"
    ],
  },
  {
    id: "levelland",
    title: "Levelland",
    place: "Levelland, Texas",
    country: "USA",
    year: 1957,
    lat: 33.587,
    lng: -102.378,
    summary: "On 2–3 November 1957, multiple drivers west of Lubbock reported a large egg-shaped object that stalled car engines and dimmed lights. Sheriff Weir Clem saw a flash. Blue Book blamed ball lightning and electrical storms. The clustered electromagnetic vehicle-interference reports remain the core of the file.",
    sources: [
          "Project Blue Book, Levelland",
          "Hockley County sheriff statements, Nov 1957"
    ],
  },
  {
    id: "rb-47",
    title: "RB-47 case",
    place: "Gulf Coast / Mississippi",
    country: "USA",
    year: 1957,
    lat: 30.4,
    lng: -88.9,
    summary: "On 17 July 1957 an Air Force RB-47 reconnaissance crew tracked an unknown on radar and ELINT gear from the Gulf into Mississippi and Texas, with a visual of a bright light. The Condon Report later treated it as a strong unknown. It is one of the best-instrumented U.S. military cases of the 1950s.",
    sources: [
          "Condon Report, RB-47 case",
          "USAF RB-47 mission notes, 17 July 1957"
    ],
  },
  {
    id: "villas-boas",
    title: "Villas Boas",
    place: "São Francisco de Sales",
    country: "Brazil",
    year: 1957,
    lat: -20.003,
    lng: -47.551,
    summary: "In October 1957 farmer Antônio Villas Boas described being taken aboard a craft and into a sexual encounter with a female occupant. A doctor recorded odd marks and radiation-like symptoms. Brazilian researchers interviewed him while the story was still local. It became the template for later abduction-with-examination reports.",
    sources: [
          "Olavo Fontes medical notes as later published",
          "Brazilian press and APRO correspondence, 1950s–60s"
    ],
  },
  {
    id: "milton-torres",
    title: "Milton Torres intercept",
    place: "East of RAF Manston",
    country: "UK",
    year: 1957,
    lat: 51.346,
    lng: 1.346,
    summary: "In May 1957, USAF fighter pilot Milton Torres, flying from Manston, was ordered to fire on a large radar target over East Anglia. The lock broke as the object accelerated out of range. Torres spoke publicly decades later. Radar-plus-order-to-arm is rare in the British file.",
    sources: [
          "USAF / RAF Manston intercept as later testified",
          "UK National Archives MoD UFO files (later release)"
    ],
  },
  {
    id: "ubatuba",
    title: "Ubatuba magnesium",
    place: "Ubatuba, São Paulo",
    country: "Brazil",
    year: 1957,
    lat: -23.434,
    lng: -45.071,
    summary: "In September 1957 fragments said to have exploded from a disc off Ubatuba were mailed to a journalist. Labs, including later analyses, found unusually pure magnesium. Provenance of the first chips is imperfect. Ubatuba remains Brazil’s most cited physical-trace metal case.",
    sources: [
          "Olavo Fontes / APRO Ubatuba sample notes",
          "Later spectrographic studies of Ubatuba magnesium"
    ],
  },
  {
    id: "fort-itaipu",
    title: "Fort Itaipu",
    place: "Forte de Itaipu, São Paulo",
    country: "Brazil",
    year: 1957,
    lat: -23.999,
    lng: -46.507,
    summary: "In November 1957 sentries at the Brazilian coastal fort of Itaipu reported a glowing object that overflew the battery; two soldiers were said to have suffered burns. Army notes exist in later Brazilian UFO collections. It is a military-base close encounter with alleged physiological effect, not a distant light.",
    sources: [
          "Brazilian Army / later FAB archive references to Itaipu 1957",
          "APRO and Brazilian press, Nov 1957"
    ],
  },
  {
    id: "west-freugh",
    title: "RAF West Freugh",
    place: "RAF West Freugh, Scotland",
    country: "UK",
    year: 1957,
    lat: 54.851,
    lng: -4.948,
    summary: "On 4 April 1957 radar at West Freugh tracked a large, slow, high object that did not match civil traffic. The report went to the Air Ministry. Declassified files treat it as unidentified. It is a clean Scottish radar unknown, with no matching visual circus.",
    sources: [
          "UK National Archives, Air Ministry / West Freugh 1957",
          "MoD UFO file releases"
    ],
  },
  {
    id: "loch-raven",
    title: "Loch Raven Dam",
    place: "Loch Raven Reservoir, Maryland",
    country: "USA",
    year: 1958,
    lat: 39.43,
    lng: -76.57,
    summary: "On 26 October 1958 two men at Loch Raven Dam reported an egg-shaped object; their car died as they approached, and they felt heat. Police took a report. Blue Book suggested a hoax or misperception. Vehicle interference plus heat is why the case stayed in the close-encounter catalogs.",
    sources: [
          "Baltimore County police report, Oct 1958",
          "Project Blue Book Loch Raven card"
    ],
  },
  {
    id: "father-gill",
    title: "Father Gill / Boianai",
    place: "Boianai, Papua New Guinea",
    country: "Papua New Guinea",
    year: 1959,
    lat: -10.02,
    lng: 149.85,
    summary: "On 26–27 June 1959, Anglican missionary William Gill and dozens of mission witnesses watched a disc with humanoid figures on top at Boianai. Gill waved; a figure waved back. The case was investigated while Gill was still in the field. It is the best-known close encounter from Melanesia.",
    sources: [
          "Rev. William Gill contemporaneous notes, June 1959",
          "Victorian UFO Research Society / later published Gill file"
    ],
  },
  {
    id: "red-bluff",
    title: "Red Bluff",
    place: "Red Bluff, California",
    country: "USA",
    year: 1960,
    lat: 40.177,
    lng: -122.236,
    summary: "On 13 August 1960, California Highway Patrol officers near Red Bluff reported a large, lighted object that directed beams at the ground and outran their car. Radar at a nearby station was later cited. Blue Book preferred an inversion. The patrol log is a solid night CE-II from the Sacramento Valley.",
    sources: [
          "California Highway Patrol statements, Aug 1960",
          "Project Blue Book Red Bluff file"
    ],
  },
  {
    id: "kapustin-yar",
    title: "Kapustin Yar",
    place: "Kapustin Yar",
    country: "Russia",
    year: 1960,
    lat: 48.58,
    lng: 45.75,
    summary: "Soviet air-defence files later published in fragments describe unknowns over the Kapustin Yar missile range in the 1960s, including a 1960s intercept attempt. The range was among the USSR’s most sensitive. Whether the tracks were test hardware or not, the paper treats them as unidentified at the time.",
    sources: [
          "Soviet air-defence fragments as later published",
          "Kapustin Yar range history"
    ],
  },
  {
    id: "hill-abduction",
    title: "Betty and Barney Hill",
    place: "Indian Head, New Hampshire",
    country: "USA",
    year: 1961,
    lat: 43.49,
    lng: -71.59,
    summary: "On 19–20 September 1961, Betty and Barney Hill reported a craft, missing time, and — under hypnosis — an examination on board. A star map Betty drew was later argued to show Zeta Reticuli. The case is the foundation of the American abduction narrative. Medical and police notes exist; the map is interpretation.",
    sources: [
          "John G. Fuller, The Interrupted Journey",
          "NH police / contemporaneous Hill notes"
    ],
  },
  {
    id: "eagle-river",
    title: "Eagle River / Simonton",
    place: "Eagle River, Wisconsin",
    country: "USA",
    year: 1961,
    lat: 45.917,
    lng: -89.244,
    summary: "On 18 April 1961, rural plumber Joe Simonton said a craft landed and occupants gave him bland pancakes in exchange for water. The Air Force had a pancake analyzed: ordinary buckwheat. Hynek still found Simonton sincere. It is a high-strangeness, low-glamour close encounter from the North Woods.",
    sources: [
          "Project Blue Book, Eagle River / Simonton",
          "USAF pancake analysis notes, 1961"
    ],
  },
  {
    id: "catalina-uso",
    title: "Catalina USO",
    place: "Santa Catalina Island",
    country: "USA",
    year: 1962,
    lat: 33.39,
    lng: -118.42,
    summary: "Through the early 1960s, boat crews and aircraft off Catalina reported lights that entered or left the water without splash — an early U.S. transmedium file. Some reports reached the Coast Guard and Blue Book. Water-entry cases are easy to dismiss as fish or flares; the better Catalina logs describe controlled motion.",
    sources: [
          "Project Blue Book coastal California cards",
          "U.S. Coast Guard southern California notes"
    ],
  },
  {
    id: "trancas",
    title: "Trancas",
    place: "Trancas, Tucumán",
    country: "Argentina",
    year: 1963,
    lat: -26.231,
    lng: -65.285,
    summary: "On 31 October 1963 the Moreno family at Estancia Santa Rosa reported several craft, beams, and a sulphurous mist that left scorch and moisture traces. Argentine police and later researchers documented the site. Trancas is a South American CE-II with physical traces, often skipped in English catalogs.",
    sources: [
          "Argentine police / Gendarmería notes, Nov 1963",
          "FAO / later Argentine UFO case collections"
    ],
  },
  {
    id: "big-sur-film",
    title: "Big Sur film",
    place: "Vandenberg AFB / Big Sur",
    country: "USA",
    year: 1964,
    lat: 34.743,
    lng: -120.572,
    summary: "In September 1964 an Air Force–linked crew filming an Atlas launch from Big Sur recorded an object that appeared to intercept the warhead. The film was classified. Later public versions are incomplete. Skeptics say booster debris; proponents say an energy weapon. The launch and the camera are not in dispute.",
    sources: [
          "Vandenberg launch records, Sept 1964",
          "Later interviews with the Big Sur camera crew"
    ],
  },
  {
    id: "holloman-landing",
    title: "Holloman landing claim",
    place: "Holloman AFB, New Mexico",
    country: "USA",
    year: 1964,
    lat: 32.852,
    lng: -106.107,
    summary: "A persistent story holds that a craft landed at Holloman in the mid-1960s and was filmed for a planned documentary. A few frames of a disc over the base have circulated. The Air Force has not authenticated a landing. Holloman is a real missile and lifting-body test site, which is why the claim attached here.",
    sources: [
          "Holloman AFB history",
          "Robert Emenegger / later documentary outtake claims"
    ],
  },
  {
    id: "exeter",
    title: "Incident at Exeter",
    place: "Exeter, New Hampshire",
    country: "USA",
    year: 1965,
    lat: 42.981,
    lng: -70.948,
    summary: "On 3 September 1965, teenager Norman Muscarello and two officers watched a large red-lighted object at close range near Exeter. Journalist John Fuller made it a book. Blue Book suggested a B-47; the officers disagreed. It is a canonical police-witness CE-I from New England.",
    sources: [
          "Exeter police reports, Sept 1965",
          "John G. Fuller, Incident at Exeter"
    ],
  },
  {
    id: "rex-heflin",
    title: "Rex Heflin photos",
    place: "Santa Ana, California",
    country: "USA",
    year: 1965,
    lat: 33.746,
    lng: -117.868,
    summary: "On 3 August 1965, highway investigator Rex Heflin shot Polaroids of a hat-shaped disc near Santa Ana. NICAP and later analysts argued authenticity; the Air Force suggested a hoax. One print vanished into an intelligence channel, then returned. The Polaroids remain a Southern California 1965-wave still.",
    sources: [
          "NICAP Heflin file",
          "Orange County highway department contemporaneous notes"
    ],
  },
  {
    id: "warminster",
    title: "Warminster Thing",
    place: "Warminster, Wiltshire",
    country: "UK",
    year: 1965,
    lat: 51.205,
    lng: -2.181,
    summary: "From 1964–65, Warminster residents reported booming sounds and craft, especially over Cradle Hill. Journalist Arthur Shuttlewood turned the town into a skywatch destination. MoD files hold some of the reports. Folklore and genuine unknowns mixed. It is the English market-town wave before the Welsh Triangle.",
    sources: [
          "UK National Archives, MoD Warminster papers",
          "Wiltshire Times contemporaneous reports"
    ],
  },
  {
    id: "edwards-afb",
    title: "Edwards AFB",
    place: "Edwards Air Force Base, California",
    country: "USA",
    year: 1965,
    lat: 34.905,
    lng: -117.884,
    summary: "Edwards, a flight-test center, generated multiple 1950s–60s reports of discs over Rogers Dry Lake, some from test pilots. Blue Book and later FOIA fragments survive. Test aircraft explain some lights. Not every Edwards unknown has a matching flight card, which is why the base stays in the file.",
    sources: [
          "Project Blue Book Edwards cards",
          "AFFTC historical notes / FOIA fragments"
    ],
  },
  {
    id: "portage-county",
    title: "Portage County chase",
    place: "Ravenna, Ohio",
    country: "USA",
    year: 1966,
    lat: 41.158,
    lng: -81.242,
    summary: "On 17 April 1966, Portage County deputies Dale Spaur and Wilbur Neff chased a lighted object from Ohio into Pennsylvania, joined by other officers. Radio traffic was recorded. Blue Book said Echo satellite and Venus. The officers described a disc that paced the cruiser. It is a classic multi-police chase.",
    sources: [
          "Portage County sheriff radio logs, 17 Apr 1966",
          "Project Blue Book Ravenna / Spaur file"
    ],
  },
  {
    id: "wanaque",
    title: "Wanaque Reservoir",
    place: "Wanaque, New Jersey",
    country: "USA",
    year: 1966,
    lat: 41.044,
    lng: -74.294,
    summary: "In January 1966, police and reservoir workers at Wanaque reported a bright object that beamed onto the ice and, some said, melted a hole. Multiple nights of reports followed. Newspapers treated it as a police case. Blue Book suggested stars and helicopters. The reservoir remains a named East Coast CE-II.",
    sources: [
          "Wanaque police statements, Jan 1966",
          "Project Blue Book Wanaque cards"
    ],
  },
  {
    id: "tully-nests",
    title: "Tully saucer nests",
    place: "Tully, Queensland",
    country: "Australia",
    year: 1966,
    lat: -17.933,
    lng: 145.923,
    summary: "On 19 January 1966, farmer George Pedley reported a rising disc and a circular depression of swirling reeds on a lagoon near Tully. Several ‘nests’ were photographed. The RAAF file survives. Skeptics prefer whirlwind; Pedley described a machine. It is Australia’s best-known physical-trace case before Westall.",
    sources: [
          "RAAF UFO files, National Archives of Australia — Tully 1966",
          "Queensland press, Jan 1966"
    ],
  },
  {
    id: "dexter-hillsdale",
    title: "Dexter–Hillsdale",
    place: "Dexter, Michigan",
    country: "USA",
    year: 1966,
    lat: 42.338,
    lng: -83.888,
    summary: "In March 1966, dozens of people around Dexter and Hillsdale, including a civil-defense director, reported lights over marshland. Hynek’s ‘swamp gas’ line became a national joke and damaged Blue Book’s credibility. The witnesses did not recant. The case is as important for the press handling as for the lights.",
    sources: [
          "Project Blue Book, Dexter–Hillsdale",
          "J. Allen Hynek press comments, March 1966"
    ],
  },
  {
    id: "falcon-lake",
    title: "Falcon Lake",
    place: "Falcon Lake, Manitoba",
    country: "Canada",
    year: 1967,
    lat: 49.69,
    lng: -95.32,
    summary: "On 20 May 1967, amateur prospector Stefan Michalak encountered a landed craft near Falcon Lake; a blast of air or exhaust burned a grid of dots into his chest. RCMP and RCAF notes, medical photos, and soil samples exist. Health Canada followed the burns. It is Canada’s premier physical-injury case.",
    sources: [
          "RCMP / RCAF Falcon Lake file",
          "Manitoba medical photographs of Michalak’s burns"
    ],
  },
  {
    id: "malmstrom",
    title: "Malmstrom Echo Flight",
    place: "Malmstrom AFB, Montana",
    country: "USA",
    year: 1967,
    lat: 47.505,
    lng: -111.187,
    summary: "On 16 March 1967, Echo Flight Minuteman missiles at Malmstrom dropped off alert as a large lighted object was reported over the site. Officers including Robert Salas later testified. The Air Force has not released a complete public explanation. Nuclear-weapon UFOs are a pattern; this is the best-named U.S. missile-shutdown file.",
    sources: [
          "USAF missile-wing notes as later cited by Salas and others",
          "Malmstrom AFB Echo Flight chronology, March 1967"
    ],
  },
  {
    id: "cussac",
    title: "Cussac",
    place: "Cussac, Haute-Loire",
    country: "France",
    year: 1967,
    lat: 44.98,
    lng: 3.06,
    summary: "On 29 August 1967 two children at Cussac reported a sphere and small beings in black who boarded and flew off, leaving a sulphur smell. Gendarmerie took statements the same day. GEIPAN still carries Cussac as a high-strangeness rural CE-III. It is a French counterpart to the American occupant cases of the 1960s.",
    sources: [
          "Gendarmerie nationale, Cussac 1967",
          "GEIPAN case file — Cussac"
    ],
  },
  {
    id: "valderas",
    title: "San José de Valderas",
    place: "San José de Valderas, Madrid",
    country: "Spain",
    year: 1967,
    lat: 40.35,
    lng: -3.78,
    summary: "On 1 June 1967 photographs of a disc with an odd symbol over San José de Valderas circulated with the UMMO affair. Later analysis argued a small model. The pictures still appear in Spanish catalogs. The file is a warning about how a contact cult and a photograph can fuse.",
    sources: [
          "Spanish press, June 1967",
          "Later photometric studies of the Valderas prints"
    ],
  },
  {
    id: "reunion-1968",
    title: "Réunion landing",
    place: "Cilaos / Saint-Denis",
    country: "Réunion",
    year: 1968,
    lat: -21.135,
    lng: 55.472,
    summary: "In 1968 witnesses on Réunion reported a landed object and small beings, later carried in French official summaries. Indian Ocean cases rarely reach English lists. Gendarmerie paper exists. It extends the 1960s Francophone close-encounter pattern off Africa.",
    sources: [
          "Gendarmerie / later GEIPAN historical notes, Réunion 1968",
          "French Indian Ocean press"
    ],
  },
  {
    id: "minot-afb",
    title: "Minot AFB",
    place: "Minot AFB, North Dakota",
    country: "USA",
    year: 1968,
    lat: 48.416,
    lng: -101.358,
    summary: "On 24 October 1968, B-52 crew, missile-site personnel, and ground radar at Minot tracked and saw a large lighted object. The bomber’s radar and the crew’s visual overlapped. Blue Book’s last months still left it messy. Minot is a SAC nuclear-base radar-visual, not a civilian flap.",
    sources: [
          "Project Blue Book, Minot AFB 24 Oct 1968",
          "B-52 radar / crew statements"
    ],
  },
  {
    id: "delphos",
    title: "Delphos ring",
    place: "Delphos, Kansas",
    country: "USA",
    year: 1971,
    lat: 39.274,
    lng: -97.765,
    summary: "On 2 November 1971, 16-year-old Ronald Johnson reported a glowing object that left a bleached, hydrophobic ring in the soil on the family farm. Samples stayed water-repellent for years. APRO and later labs tested them. The ring is a physical-trace classic; the craft identification is open.",
    sources: [
          "APRO Delphos investigation",
          "Soil-sample analyses as later published"
    ],
  },
  {
    id: "yakima",
    title: "Yakima Reservation lights",
    place: "Toppenish, Washington",
    country: "USA",
    year: 1972,
    lat: 46.377,
    lng: -120.309,
    summary: "Fire lookouts and tribal police on the Yakima Reservation logged years of unexplained lights, especially in the early 1970s, some near restricted ridges. Investigator Gregory Long later compiled the reports. The pattern resembles other high-plateau ‘earthlight’ files, with a few structured-craft reports mixed in.",
    sources: [
          "Yakima Indian Reservation fire-lookout logs",
          "Gregory Long, Examining the Earthlight Theory"
    ],
  },
  {
    id: "coyne",
    title: "Coyne helicopter",
    place: "Mansfield, Ohio",
    country: "USA",
    year: 1973,
    lat: 40.758,
    lng: -82.515,
    summary: "On 18 October 1973, an Army Reserve Huey commanded by Lawrence Coyne encountered a metallic object that bathed the cockpit in green light; the helicopter briefly climbed without Coyne’s input. Four crew members signed the report. The FAA and Army took statements. It is a premier aircrew close encounter of the 1973 wave.",
    sources: [
          "U.S. Army Reserve / FAA Coyne statements, Oct 1973",
          "J. Allen Hynek investigation notes"
    ],
  },
  {
    id: "pascagoula",
    title: "Pascagoula",
    place: "Pascagoula, Mississippi",
    country: "USA",
    year: 1973,
    lat: 30.366,
    lng: -88.556,
    summary: "On 11 October 1973, Charles Hickson and Calvin Parker said robotic beings took them from a pier on the Pascagoula River. A hidden sheriff’s-office tape caught them still terrified when they thought they were alone. The 1973 wave had many occupant reports; this one has that tape.",
    sources: [
          "Jackson County sheriff interview tape, Oct 1973",
          "Hickson and Parker contemporaneous statements"
    ],
  },
  {
    id: "travis-walton",
    title: "Travis Walton",
    place: "Apache-Sitgreaves, Arizona",
    country: "USA",
    year: 1975,
    lat: 34.337,
    lng: -110.644,
    summary: "On 5 November 1975, logger Travis Walton vanished after a bright object in the forest; six coworkers told the same story. Walton reappeared five days later with an abduction account. Polygraphs were mixed. Navajo County records exist. It is the American West’s most famous missing-time timber-crew case.",
    sources: [
          "Navajo County sheriff file, Nov 1975",
          "Travis Walton, The Walton Experience"
    ],
  },
  {
    id: "northern-tier",
    title: "Northern Tier / Loring",
    place: "Loring AFB, Maine",
    country: "USA",
    year: 1975,
    lat: 46.95,
    lng: -67.89,
    summary: "In late October 1975, SAC bases along the northern tier — Loring, Wurtsmith, Malmstrom, Minot — logged unidentified helicopters or craft over weapons storage. NORAD and base police traffic was later released. The Air Force spoke of helicopters; none were caught. It is a multi-base nuclear-security unknown, not a single light in a field.",
    sources: [
          "NORAD / SAC message traffic, Oct–Nov 1975 (FOIA)",
          "Loring AFB security police logs"
    ],
  },
  {
    id: "wurtsmith",
    title: "Wurtsmith AFB",
    place: "Wurtsmith AFB, Michigan",
    country: "USA",
    year: 1975,
    lat: 44.45,
    lng: -83.4,
    summary: "During the 1975 northern-tier wave, Wurtsmith logged an unknown near a B-52 and the weapons area. Crews and security police filed. The incident is often folded into Loring; the Michigan paper is separate. A nuclear bomber base is not a place the Air Force ignored.",
    sources: [
          "Wurtsmith AFB security logs, 1975 (FOIA)",
          "SAC northern-tier compilation"
    ],
  },
  {
    id: "kofu",
    title: "Kofu",
    place: "Kofu, Yamanashi",
    country: "Japan",
    year: 1975,
    lat: 35.664,
    lng: 138.568,
    summary: "On 23 February 1975 two boys in Kofu reported a landed craft and small beings; other residents reported a light. Japanese press covered it heavily. Police took notes. It is a lesser-known Japanese close encounter from the same decade as the better-cited airliner cases.",
    sources: [
          "Yamanashi police / press, Feb 1975",
          "Japan UFO Research contemporaneous file"
    ],
  },
  {
    id: "mar-del-plata",
    title: "Mar del Plata",
    place: "Mar del Plata",
    country: "Argentina",
    year: 1975,
    lat: -38.005,
    lng: -57.543,
    summary: "Argentine Navy and civil observers at Mar del Plata logged unexplained lights and sea-landing reports in the mid-1970s. Some went into official naval notes. The South Atlantic produces USO stories; this file is one of the better-cited Argentine coastal clusters.",
    sources: [
          "Argentine Navy / prefectura notes as later published",
          "Buenos Aires province press, 1970s"
    ],
  },
  {
    id: "canary-1976",
    title: "Canary Islands 1976",
    place: "Gran Canaria",
    country: "Spain",
    year: 1976,
    lat: 27.92,
    lng: -15.55,
    summary: "On 22 June 1976 a huge, luminous object was seen across the Canary Islands, including by a doctor who described a sphere and beings inside. Spanish Air Force files later released treat the event as unidentified. Multiple islands, many witnesses, one night. It is Spain’s flagship official case along with Manises.",
    sources: [
          "Spanish Air Force Canary Islands file, 1976 (later declassified)",
          "Dr. Francisco Padron contemporaneous account"
    ],
  },
  {
    id: "chupas",
    title: "Chupas",
    place: "Chupas, Ayacucho",
    country: "Peru",
    year: 1977,
    lat: -13.16,
    lng: -74.22,
    summary: "On 1 October 1977 a Peruvian Air Force C-47 crew, including the defense minister’s group, reported a craft that paced the aircraft near Chupas with a blinding light. Crew and passengers were interviewed. It is a South American official aircrew case, less famous than Tehran the year before.",
    sources: [
          "Fuerza Aérea del Perú crew statements, Oct 1977",
          "Peruvian press pool, 1977"
    ],
  },
  {
    id: "putre",
    title: "Putre",
    place: "Putre, Arica y Parinacota",
    country: "Chile",
    year: 1977,
    lat: -18.196,
    lng: -69.559,
    summary: "In 1977 Chilean Army corporal Armando Valdés in the Putre highlands reported a landed object and missing time; his watch and calendar allegedly jumped. Army statements exist. Skeptics see folklore at altitude. The case is a named Andean CE-III in official uniform.",
    sources: [
          "Ejército de Chile statements on the Valdés incident",
          "Chilean press, 1977"
    ],
  },
  {
    id: "kaikoura",
    title: "Kaikōura lights",
    place: "Kaikōura",
    country: "New Zealand",
    year: 1978,
    lat: -42.4,
    lng: 173.68,
    summary: "On 21 December 1978 an Argosy freighter crew and a TV cameraman filmed lights off Kaikōura that Wellington radar also tracked. The RNZAF later preferred squid-boat lights and radar artifacts. The film and the radar tape still exist. It is New Zealand’s best-known radar-visual.",
    sources: [
          "RNZAF / Wellington radar notes, Dec 1978",
          "Channel 0 Kaikōura film"
    ],
  },
  {
    id: "emilcin",
    title: "Emilcin",
    place: "Emilcin",
    country: "Poland",
    year: 1978,
    lat: 51.14,
    lng: 22.04,
    summary: "On 10 May 1978 farmer Jan Wolski described a craft and short beings who examined him in a field at Emilcin. Polish investigators took a fresh statement. A memorial now stands at the site. It is Poland’s most famous close encounter, with a thin but real contemporary paper trail.",
    sources: [
          "Polish civilian investigation notes, May 1978",
          "Lublin regional press"
    ],
  },
  {
    id: "zanfretta",
    title: "Zanfretta / Torriglia",
    place: "Torriglia, Liguria",
    country: "Italy",
    year: 1978,
    lat: 44.52,
    lng: 9.16,
    summary: "Night watchman Pier Fortunato Zanfretta reported repeated encounters with giant beings near Torriglia from 1978. Carabinieri statements and hypnosis tapes exist. Italian ufology split over the case. It is a high-strangeness security-guard file, not a distant light over a city.",
    sources: [
          "Carabinieri statements, Torriglia 1978",
          "Italian CUN / CISU case notes"
    ],
  },
  {
    id: "kuwait-oil",
    title: "Kuwait oil field",
    place: "Umm Alaish oil field",
    country: "Kuwait",
    year: 1978,
    lat: 29,
    lng: 47.7,
    summary: "In November 1978 Kuwaiti oil technicians and a gathering-station crew reported a landed disc that coincided with a communications and pumping outage. A Kuwaiti government memo went to the U.S. Embassy. The object departed; systems returned. It is a rare Gulf industrial CE-II with diplomatic paper.",
    sources: [
          "U.S. Embassy Kuwait cable / State Department file, 1978",
          "Kuwait Oil Company witness notes"
    ],
  },
  {
    id: "dechmont",
    title: "Dechmont Law",
    place: "Livingston, West Lothian",
    country: "UK",
    year: 1979,
    lat: 55.91,
    lng: -3.5,
    summary: "On 9 November 1979 forestry worker Bob Taylor reported a sphere and spiked mines that tugged his trousers on Dechmont Law. Police logged it as a criminal assault. Ground traces and torn clothing were photographed. It is the only UFO case on Scottish police books as an assault.",
    sources: [
          "Lothian and Borders Police report, Nov 1979",
          "UK National Archives / contemporaneous Scottish press"
    ],
  },
  {
    id: "manises",
    title: "Manises",
    place: "Valencia / Manises Airport",
    country: "Spain",
    year: 1979,
    lat: 39.489,
    lng: -0.482,
    summary: "On 11 November 1979 a commercial flight to Tenerife was forced to divert to Manises after a red object paced the airliner. Spanish Air Force jets scrambled. The official file, later released, does not close the case. It is Spain’s best-known aviation encounter.",
    sources: [
          "Ejército del Aire, Manises incident file (declassified)",
          "Iberia / TAE crew statements, Nov 1979"
    ],
  },
  {
    id: "cergy-pontoise",
    title: "Cergy-Pontoise",
    place: "Cergy, Val-d'Oise",
    country: "France",
    year: 1979,
    lat: 49.036,
    lng: 2.063,
    summary: "In November 1979 Franck Fontaine vanished from a Cergy-Pontoise road after his friends reported a light; he reappeared days later with an abduction story. Gendarmerie investigated. Later doubts and recantations damaged the case. It remains a named French missing-time file of the late 1970s.",
    sources: [
          "Gendarmerie nationale, Cergy-Pontoise 1979",
          "French press, Nov–Dec 1979"
    ],
  },
  {
    id: "soesterberg",
    title: "Soesterberg",
    place: "Soesterberg Air Base",
    country: "Netherlands",
    year: 1979,
    lat: 52.127,
    lng: 5.276,
    summary: "Dutch and USAF personnel at Soesterberg filed late-1970s reports of unknowns over the joint base, some with radar. NATO air-defence logs are thinly released. The Netherlands later ran a small official UFO desk. Soesterberg is a Low Countries military pin often missed on English maps.",
    sources: [
          "RNLAF / USAF Soesterberg notes as later cited",
          "Dutch official UFO policy summaries"
    ],
  },
  {
    id: "cash-landrum",
    title: "Cash–Landrum",
    place: "Dayton, Texas",
    country: "USA",
    year: 1980,
    lat: 30.047,
    lng: -94.89,
    summary: "On 29 December 1980 Betty Cash, Vickie Landrum and Colby Landrum encountered a diamond-shaped object over a Texas road, with helicopters around it. All three fell ill; Cash was hospitalized. They sued the U.S. government and lost. No agency claimed the helicopters. It is a civilian injury case with a court record.",
    sources: [
          "Cash–Landrum federal court filings",
          "Texas Department of Health / medical records as cited in court"
    ],
  },
  {
    id: "el-yunque",
    title: "El Yunque",
    place: "El Yunque National Forest",
    country: "Puerto Rico",
    year: 1980,
    lat: 18.31,
    lng: -65.79,
    summary: "From around 1980, Puerto Rican witnesses described discs, low-level craft, and later chupacabra lore in El Yunque. Some reports reached police and later the island’s UFO researchers. Jungle, radar, and Roosevelt Roads naval airspace overlap. The rainforest is a long-running Caribbean high-strangeness pin.",
    sources: [
          "Puerto Rico police / press reports, 1980s",
          "Later compilations of El Yunque sightings"
    ],
  },
  {
    id: "hessdalen",
    title: "Hessdalen lights",
    place: "Hessdalen, Trøndelag",
    country: "Norway",
    year: 1981,
    lat: 62.793,
    lng: 11.191,
    summary: "Since December 1981 the Hessdalen valley has produced recurring unexplained lights, studied by Project Hessdalen with magnetometers, cameras, and radar. Some lights show structured motion. No consensus identification exists. It is Europe’s longest instrumental earthlight / UAP study, not a one-night flap.",
    sources: [
          "Project Hessdalen technical reports",
          "University of Oslo / Østfold measurements"
    ],
  },
  {
    id: "baikal-divers",
    title: "Lake Baikal divers",
    place: "Lake Baikal",
    country: "Russia",
    year: 1982,
    lat: 53.5,
    lng: 108,
    summary: "A late-Soviet story, later told by veterans, describes Navy divers in Lake Baikal encountering humanoid figures in silvery suits, with casualties in the panic. Contemporary public paper is thin. It is filed as a USO / underwater-humanoid claim from the USSR’s most sensitive lake, not as a closed case.",
    sources: [
          "Later Russian Navy veteran interviews as published",
          "Soviet / Russian press retrospectives on Baikal"
    ],
  },
  {
    id: "hudson-valley",
    title: "Hudson Valley wave",
    place: "Pine Bush, New York",
    country: "USA",
    year: 1983,
    lat: 41.608,
    lng: -74.299,
    summary: "From 1982–86, thousands along the Hudson Valley reported a silent, lighted boomerang. Police switchboards filled. Some nights were later tied to ultralight formations; others were not. J. Allen Hynek investigated. It is the largest U.S. civilian wave between the 1960s and Phoenix.",
    sources: [
          "Hynek / CUFOS Hudson Valley notes",
          "NY and CT police blotters, 1983–84"
    ],
  },
  {
    id: "gulf-breeze",
    title: "Gulf Breeze",
    place: "Gulf Breeze, Florida",
    country: "USA",
    year: 1987,
    lat: 30.357,
    lng: -87.164,
    summary: "In 1987 Ed Walters produced Polaroids of a lighted craft over Gulf Breeze; other residents reported lights. A model later found in a house attic fed the hoax charge. Walters never recanted. The town became a skywatch scene. The photographs remain contested; the cluster of independent reports is separate.",
    sources: [
          "Gulf Breeze Sentinel photographs, 1987",
          "Florida Department of Law Enforcement / local press"
    ],
  },
  {
    id: "ilkley-moor",
    title: "Ilkley Moor",
    place: "Ilkley Moor, West Yorkshire",
    country: "UK",
    year: 1987,
    lat: 53.915,
    lng: -1.823,
    summary: "In December 1987 a retired policeman photographed a small being on Ilkley Moor and described a missing-time encounter. The print was widely published in British ufology. Skeptics call it a dummy. There is no official MoD file of weight. It is a named English CE-III still.",
    sources: [
          "UK contemporaneous ufology publications, 1988",
          "West Yorkshire press notes"
    ],
  },
  {
    id: "mundrabilla",
    title: "Knowles / Mundrabilla",
    place: "Mundrabilla, Nullarbor",
    country: "Australia",
    year: 1988,
    lat: -31.82,
    lng: 128.23,
    summary: "On 20 January 1988 the Knowles family said a craft lifted or covered their Ford on the Nullarbor near Mundrabilla, coating it with ash and denting the roof. Police in Ceduna photographed the car. Lab tests on the dust were inconclusive. It is Australia’s best-known highway CE-II of the 1980s.",
    sources: [
          "South Australia Police, Ceduna, Jan 1988",
          "Australian press pool, Knowles family interviews"
    ],
  },
  {
    id: "fyffe",
    title: "Fyffe",
    place: "Fyffe, Alabama",
    country: "USA",
    year: 1989,
    lat: 34.437,
    lng: -85.907,
    summary: "In February 1989 police and townsfolk in Fyffe reported large lighted objects, drawing national crews. Officers signed statements. The town later leaned into the story. Prosaic traffic and a genuine unknown may both have been present. It is a named Appalachian police wave.",
    sources: [
          "Fyffe / DeKalb County police statements, Feb 1989",
          "Alabama press, 1989"
    ],
  },
  {
    id: "reitz-sa",
    title: "Reitz",
    place: "Reitz, Free State",
    country: "South Africa",
    year: 1990,
    lat: -27.801,
    lng: 28.427,
    summary: "South African police and farmers around Reitz reported close-range craft and landings around 1990, in a thin but persistent file. Apartheid-era air-defence notes are poorly released. It is a lesser-known African rural cluster from the same era as the better-cited Zimbabwe school case.",
    sources: [
          "South African Police contemporaneous notes as later cited",
          "Free State press, c. 1990"
    ],
  },
  {
    id: "mexico-eclipse",
    title: "Mexico City eclipse disc",
    place: "Mexico City",
    country: "Mexico",
    year: 1991,
    lat: 19.432,
    lng: -99.133,
    summary: "During the 11 July 1991 solar eclipse, multiple video cameras in Mexico City recorded a stationary metallic disc in daylight. Skeptics prefer a balloon. The mass of independent tapes is why the file survived. It is the best-known Mexican daylight video case of the 1990s.",
    sources: [
          "Multiple independent Mexico City videotapes, 11 July 1991",
          "Mexican press and later photometric discussions"
    ],
  },
  {
    id: "bonnybridge",
    title: "Bonnybridge",
    place: "Bonnybridge, Falkirk",
    country: "UK",
    year: 1992,
    lat: 56,
    lng: -3.887,
    summary: "From the early 1990s the Bonnybridge area logged an unusual density of UFO reports, enough that local politicians asked the MoD for an inquiry. Most cases are lights. A few are structured-craft claims. The ‘Falkirk Triangle’ is a long-running statistical cluster, not a single night.",
    sources: [
          "Falkirk Council / MP correspondence with MoD",
          "UK National Archives UFO files — Bonnybridge"
    ],
  },
  {
    id: "jodhpur",
    title: "Jodhpur",
    place: "Jodhpur, Rajasthan",
    country: "India",
    year: 1995,
    lat: 26.238,
    lng: 73.024,
    summary: "Indian Air Force and civil observers around Jodhpur reported unidentified lights in the mid-1990s, some during heightened western-sector alert. Parliamentary answers later treated a subset as unidentified. It adds a named Indian pin to the thinner public IAF file.",
    sources: [
          "Lok Sabha Defence replies on unidentified aircraft",
          "Rajasthan press, 1990s"
    ],
  },
  {
    id: "bariloche",
    title: "Bariloche",
    place: "San Carlos de Bariloche",
    country: "Argentina",
    year: 1995,
    lat: 41.133,
    lng: -71.31,
    summary: "On 31 July 1995 an Aerolíneas Argentinas 727 on approach to Bariloche encountered a large object; airport lights and some instruments failed as it passed. The Argentine Air Force investigated. Crew and tower statements exist. It is a South American aviation CE-II with an official inquiry.",
    sources: [
          "Fuerza Aérea Argentina Bariloche inquiry, 1995",
          "Aerolíneas Argentinas crew statements"
    ],
  },
  {
    id: "yukon-giant",
    title: "Yukon giant",
    place: "Fox Lake, Yukon",
    country: "Canada",
    year: 1996,
    lat: 61.35,
    lng: -135.3,
    summary: "On 11 December 1996 a huge, lighted, silent craft was reported along the Klondike Highway by multiple motorists, including a hunting party that described a row of lights the size of a stadium. RCMP took calls. No aircraft matched. It is Canada’s largest 1990s structured-craft case.",
    sources: [
          "RCMP Yukon call logs, 11 Dec 1996",
          "Martin Jasek / later witness compilation"
    ],
  },
  {
    id: "stephenville",
    title: "Stephenville",
    place: "Stephenville, Texas",
    country: "USA",
    year: 2008,
    lat: 32.221,
    lng: -98.202,
    summary: "On 8 January 2008, officers, pilots, and townsfolk around Stephenville reported a huge lighted object; FAA radar data later released showed an unknown near military traffic. The Air Force first denied, then cited training. The radar plots remain the core. It is the best U.S. civilian-radar case of the 2000s.",
    sources: [
          "FAA radar data, Stephenville, Jan 2008",
          "Erath County witness statements"
    ],
  },
  {
    id: "needles-2008",
    title: "Needles crash claim",
    place: "Needles, California",
    country: "USA",
    year: 2008,
    lat: 34.848,
    lng: -114.614,
    summary: "On 29 May 2008 witnesses near Needles described a flaming, winged or cylindrical object going down, followed by blacked-out helicopters. Investigator Tom Dongo and later George Knapp publicized the story. No NTSB crash was logged. It is a modern desert retrieval claim with multiple night witnesses.",
    sources: [
          "San Bernardino County witness reports, May 2008",
          "Later Knapp / KLAS coverage of the Needles object"
    ],
  },
  {
    id: "mosul-orb",
    title: "Mosul orb",
    place: "Mosul",
    country: "Iraq",
    year: 2016,
    lat: 36.34,
    lng: 43.13,
    summary: "U.S. military personnel in Iraq recorded a small spherical object in daylight near Mosul; AARO later posted related official imagery from the Middle East theater. The clip is a sensor case, not a tabloid still. Identification has not been public. It pins a 2010s combat-zone UAP on the map.",
    sources: [
          "AARO official UAP imagery https://www.aaro.mil/uap-cases/official-uap-imagery/",
          "U.S. military Middle East sensor releases"
    ],
  },
  {
    id: "eglin-2023",
    title: "Eglin AFB",
    place: "Eglin AFB, Florida",
    country: "USA",
    year: 2023,
    lat: 30.48,
    lng: -86.53,
    summary: "In 2023 an Eglin pilot photographed an object over the Gulf; members of Congress were later briefed. AARO has discussed Gulf sensor cases. The still is one of the few named 2020s Air Force photographs in public conversation. The base is a test range — prosaic traffic exists — and the briefing still happened.",
    sources: [
          "Congressional UAP briefing reporting, 2023",
          "AARO / USAF Gulf of Mexico case notes"
    ],
  },
  {
    id: "langley-drones",
    title: "Langley incursions",
    place: "Langley AFB, Virginia",
    country: "USA",
    year: 2023,
    lat: 37.083,
    lng: -76.36,
    summary: "In December 2023, Langley AFB reported a days-long swarm of unidentified drones that grounded or disrupted operations. The Pentagon confirmed incursions without a public identification. The 2024 East Coast drone wave followed. Whether hobby drones, foreign ISR, or something else, the airspace was not closed by a known NOTAM fleet.",
    sources: [
          "U.S. Air Force / NORAD statements, Dec 2023",
          "DoD briefings on Langley drone incursions"
    ],
  },
];
